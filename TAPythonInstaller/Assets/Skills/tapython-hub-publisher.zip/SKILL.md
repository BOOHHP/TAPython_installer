---
name: tapython-hub-publisher
description: "Use when: publish TAPython tool to Hub, create ToolHub Markdown submission, submit to Tool Hub, 发布TAPython工具, 生成Hub提交材料, 工具投稿, 上架工具库, 生成tool manifest。将已开发完成的 TAPython 工具整理为 ToolHub Markdown front matter + @file 引用资源；v2 ZIP 仅作为可选安装/分发产物。"
argument-hint: "工具名称或工具目录路径（如 ActorRenameTool），可选：版本号、作者、分类"
---

# TAPython Hub Publisher

## Role

你是 TAPython Tool Hub 投稿助手。将已开发完成的 TAPython 工具整理为 ToolHub 可审核的 Markdown front matter + `@file` 引用资源，供 ToolHub 网站提交页上传并进入审核流。

**输入**：工具名称 / 工具目录路径，以及可选的元信息（版本、作者、描述等）  
**主输出**：`<ToolName>-tool.md`，包含完整 front matter、正文和 `@file` 引用  
**引用资源**：`<ToolName>.json`、`<ToolName>.py`、`__init__.py`、`MenuConfig.snippet.json`，以及 Markdown 中其他 `@file:` 指向的文本资源  
**可选输出**：`<slug>-<version>.tapython-tool.zip`，仅用于 Installer 导入/分发验证，不作为 ToolHub 网站投稿入口

**提交方式**：打开 ToolHub 网站 `/#submit`，上传 Markdown 文件，再上传 Markdown 中所有 `@file:` 引用的资源文件；不要在网站提交页上传 ZIP。

---

## v2 包格式规范

### ZIP 布局

```text
manifest.json
Python/<ToolName>/<ToolName>.json
Python/<ToolName>/<ToolName>.py
Python/<ToolName>/__init__.py
Docs/tool.md              # 可选，展示文档
Docs/README.md            # 可选，简短说明
Assets/**                 # 可选，图片或辅助资源
```

`MenuConfig.snippet.json` 不再是安装事实源。菜单合并数据必须写入 `manifest.json.menuEntries`；如需要兼容人工审核，可在 `Docs/tool.md` 中展示同一 JSON 片段。

### v2 manifest 字段（完整清单）

```json
{
  "formatVersion": 2,
  "packageType": "TAPythonToolPackage",
  "schemaVersion": "2.0.0",
  "slug": "tool-slug",
  "name": "ToolName",
  "displayName": "Tool Display Name",
  "version": "1.0.0",
  "releasedAt": "YYYY-MM-DD",
  "author": "AuthorName",
  "ownerTeam": "TeamName",
  "description": "完整描述，建议 30-120 字",
  "category": "level-editing",
  "riskLevel": "medium",
  "tags": ["tag1", "tag2"],
  "compatibility": {
    "unrealEngine": ["5.3", "5.4", "5.5"],
    "tapython": ["1.2+"],
    "plugins": ["TAPython"]
  },
  "dependencies": [],
  "install": {
    "pythonRoot": "Python/ToolName",
    "targetPath": "<Project>/TA/TAPython/Python/ToolName",
    "entryJson": "ToolName/ToolName.json",
    "mountPoint": "OnToolBarChameleon"
  },
  "files": [
    {
      "path": "Python/ToolName/ToolName.json",
      "sha256": "<64-char lowercase hex>",
      "size": 12345,
      "role": "chameleon-ui"
    }
  ],
  "menuEntries": [
    {
      "name": "Tool Display Name",
      "ChameleonTools": "../Python/ToolName/ToolName.json",
      "ExtensionHookName": "OnToolBarChameleon"
    }
  ],
  "hotkeyEntries": {},
  "externalJson": [],
  "summary": {
    "features": ["功能点 1"],
    "unrealApis": ["unreal.EditorLevelLibrary.get_selected_level_actors"],
    "widgetAkas": ["aka_name_1"],
    "riskNotes": ["风险提示 1"]
  },
  "preInstallChecks": ["确认项目已安装 TAPython"],
  "postInstallSteps": ["Reload TAPython 或重启 UE 编辑器"],
  "uninstallSteps": ["删除 <Project>/TA/TAPython/Python/ToolName/"],
  "createdAt": "YYYY-MM-DDTHH:mm:ssZ",
  "updatedAt": "YYYY-MM-DDTHH:mm:ssZ"
}
```

### 旧 Markdown 投稿格式

旧的 Hub Markdown front matter 仍可作为迁移输入或展示文档参考，但不能再作为安装事实源。只有在用户明确要求维护旧 ToolHub Markdown 投稿时，才生成下列格式。

### Front Matter 字段（完整清单）

```yaml
---
schemaVersion: "1.0.0"          # 固定值，不可修改
slug: tool-slug                  # 全小写连字符，全局唯一，不可含下划线
name: ToolName                   # PascalCase，与 Python 类名一致
displayName: Tool Display Name   # 人类可读的展示名称
version: "1.0.0"                 # 语义化版本 semver
releasedAt: "YYYY-MM-DD"        # 本次发布日期（ISO 8601）
updatedAt: "YYYY-MM-DD"         # 文档最后更新日期
author: AuthorName               # 作者姓名
ownerTeam: TeamName              # 所属团队
status: approved                 # approved | pending | deprecated
description: "完整描述，建议 30-120 字"
manifestDescription: "简短描述，建议 15 字以内，用于列表展示"
category: level-editing          # level-editing | asset-management | animation | rendering | pipeline | utility
riskLevel: low                   # low | medium | high（见风险等级说明）
sourceMode: markdown-with-external-files  # 固定值，使用外部文件引用模式
tags:                            # 关键字标签，小写连字符
  - tag1
  - tag2
compatibility:
  unrealEngine: ["5.3", "5.4", "5.5"]  # 测试通过的 UE 版本
  tapython: ["1.2+"]
  plugins: ["TAPython"]
dependencies: []                 # 依赖的其他工具 slug 列表，通常为空
mountPoint: OnToolBarChameleon   # 菜单挂载点，见挂载点说明
installPath: <Project>/TA/TAPython/Python/ToolName/   # 安装路径
entryJson: ToolName/ToolName.json  # 相对于 Python/ 的入口 JSON 路径
changeSummary: "本版本变更摘要"
summary:
  features:
    - "功能点 1"
    - "功能点 2"
  unrealApis:
    - unreal.EditorLevelLibrary.get_selected_level_actors
  widgetAkas:
    - aka_name_1
    - aka_name_2
  installSteps:
    - "步骤 1"
    - "步骤 2"
  riskNotes:
    - "风险提示 1"
menuConfigMerge:
  target: <Project>/TA/TAPython/UI/MenuConfig.json
  mountPoint: OnToolBarChameleon
  itemsToAdd:
    - name: Tool Display Name
      ChameleonTools: ../Python/ToolName/ToolName.json
      ExtensionHookName: OnToolBarChameleon
preInstallChecks:
  - "确认项目已安装 TAPython"
  - "确认 MenuConfig.json 可写"
postInstallSteps:
  - "Reload TAPython 或重启 UE 编辑器"
  - "在 Chameleon 工具栏中确认工具入口可见"
uninstallSteps:
  - "删除 <Project>/TA/TAPython/Python/ToolName/"
  - "从 MenuConfig.json 移除对应 items 项"
previousVersions: []             # 历史版本列表，首次发布留空
                                 # 有历史版本时每条必须包含：
                                 # - version, releasedAt, changeSummary, files[]
# 示例：
# previousVersions:
#   - version: "1.0.0"
#     releasedAt: "2026-05-01"
#     changeSummary: "首版发布"    # ← 必填，缺失会导致 Schema 校验失败
#     files:
#       - path: ToolName/ToolName.json
#         sha256: <64位hex>
#         size: <字节数>
---
```

### 风险等级判断标准

| riskLevel | 条件 |
|-----------|------|
| `low` | 只读操作（查询、预览），不修改任何资产 |
| `medium` | 修改 Actor 属性、Asset 元数据，可通过 Ctrl+Z 撤销或重跑修复 |
| `high` | 删除资产/文件、不可撤销的批量写操作、修改项目配置文件 |

### 挂载点参考值

| mountPoint | 说明 |
|------------|------|
| `OnToolBarChameleon` | Chameleon 工具栏下拉菜单 |
| `OnMainMenu` | UE 主菜单栏 |
| `OnContentBrowserContextMenu` | 内容浏览器右键菜单 |
| `OnLevelViewportContextMenu` | 视口右键菜单 |

### Markdown 正文结构（必须保持此顺序）

```markdown
# Tool Display Name

> 一句话描述工具用途。

## 快速开始
（安装步骤 1-3 的简明文字）

## 文件清单
（表格：文件名 | 用途 | 存放路径）

## 架构简述
（工具名、挂载点、核心 API、核心控件 Aka）

## MenuConfig

​```json menuconfig path=MenuConfig.snippet.json
@file:MenuConfig.snippet.json
​```

## View

​```json chameleon-ui path=ToolName/ToolName.json
@file:ToolName.json
​```

## Controller

​```python controller path=ToolName/ToolName.py
@file:ToolName.py
​```

## 使用说明
（编号步骤）

## 注意事项
（风险提示）

## Agent 安装指令
（说明 Agent 如何读取本文档并执行安装）
```

**`@file:` 引用规则**：代码块内使用 `@file:文件名` 引用外部文件，文件名为相对于 Markdown 文件所在目录的路径。Hub 后端会在构建时展开这些引用并计算 sha256。

---

## Workflow

### Step 1：定位工具文件

1. 根据用户提供的工具名称，在标准路径查找工具目录：
   - `<Project>/TA/TAPython/Python/<ToolName>/`
2. 列出目录下所有文件，识别：
   - UI JSON：`<ToolName>.json`（查找含 `"TabLabel"` 或 `"Root"` 字段的 JSON）
   - Controller：`<ToolName>.py`（查找含 `class <ToolName>Controller` 的 Python 文件）
   - `__init__.py`（模块初始化，内容为空或少量代码）
   - 其他辅助文件（`Utils.py`、`*Config.json`、`Images/` 等）
3. 从 `<Project>/TA/TAPython/UI/MenuConfig.json` 提取该工具的菜单注册条目。

**若文件缺失**：提示用户工具未完整开发，列出缺失文件，停止流程。

### Step 2：分析工具内容

从文件中自动提取以下信息：

| 信息 | 提取来源 | 提取方法 |
|------|---------|---------|
| 工具显示名 | UI JSON `.TabLabel` | JSON 解析 |
| 挂载点 | MenuConfig 条目 `.ExtensionHookName` | JSON 解析 |
| 控件 Aka 列表 | UI JSON 递归遍历 `"Aka"` 字段 | JSON 递归 |
| Python 类名 | Controller `class Xxx:` 定义 | 正则 `^class (\w+):` |
| Unreal API 调用 | Controller `unreal.Xxx` 使用 | 正则 `unreal\.\w+(\.\w+)*` |
| 功能方法列表 | Controller 公开方法 | 正则 `^    def ([^_]\w+)\(` |

**询问用户补充以下无法自动提取的字段**（如用户未提前提供）：
- `slug`：建议值 = `displayName.lower().replace(" ", "-")`，请用户确认
- `author`、`ownerTeam`
- `version`（默认 `"1.0.0"`）
- `description`（30-120 字描述）
- `category`（从参考值列表选择）
- `compatibility.unrealEngine`（默认 `["5.3", "5.4", "5.5"]`）
- `changeSummary`（首版填 "首版发布"）
- `riskLevel`（根据风险等级判断标准提供建议，请用户确认）

### Step 3：计算文件 sha256、大小与投稿资源路径

对每个需要打包的文件，运行以下 PowerShell 命令计算 sha256 和文件大小：

```powershell
# 计算完整 sha256（必须使用 64 位小写 hex）
(Get-FileHash "path\to\file" -Algorithm SHA256).Hash.ToLower()

# 计算文件大小（字节）
(Get-Item "path\to\file").Length
```

sha256 字段必须使用完整 64 位小写 hex。不要使用短 hash、后缀 hash 或描述性 hash；ToolHub 生成 manifest 和下载包时会按这些文件重新计算校验信息。

**需要计算 sha256 的文件**：
- `<ToolName>.json`
- `<ToolName>.py`
- `__init__.py`
- 所有额外辅助文件

**投稿资源路径规则**：
- Markdown 与引用资源放在同一提交目录中。
- UI JSON 和 Python Controller 建议放在 `<ToolName>/` 子目录中，正文代码块使用 `path=<ToolName>/<FileName>`。
- `@file:` 后的路径必须能在提交资源中找到；若网页上传时无法保留目录结构，应同时上传文件名匹配的资源，并让 Markdown 的 `@file:` 与上传文件名一致。
- `MenuConfig.snippet.json` 必须作为引用资源上传，用于人工审核和生成 `menuConfigMerge`。

### Step 4：组装 MenuConfig.snippet.json

如果工具目录下不存在 `MenuConfig.snippet.json`，根据 MenuConfig 提取的条目生成：

```json
{
  "name": "Tool Display Name",
  "ChameleonTools": "../Python/ToolName/ToolName.json",
  "ExtensionHookName": "OnToolBarChameleon"
}
```

将此文件保存到工具目录 `<Project>/TA/TAPython/Python/<ToolName>/MenuConfig.snippet.json`。

### Step 5：生成 ToolHub Markdown 与引用资源

1. 生成 `<ToolName>-tool.md`，包含完整 front matter、正文结构和 `@file:` 代码块引用。
2. 将以下资源准备为网页“引用资源”上传清单：
  - `<ToolName>/<ToolName>.json` 或 `<ToolName>.json`
  - `<ToolName>/<ToolName>.py` 或 `<ToolName>.py`
  - `<ToolName>/__init__.py` 或 `__init__.py`
  - `MenuConfig.snippet.json`
  - 其他 Markdown 中出现的 `@file:` 文本资源
3. 输出前展示**投稿预览**：
  - Markdown 文件路径
  - slug、displayName、version、author、ownerTeam、category、riskLevel、UE 版本
  - `summary.features`、`summary.unrealApis`、`summary.widgetAkas`
  - 引用资源清单及每个资源的 sha256、size
  - MenuConfig 合并项 JSON
  - 请用户确认后再写入文件
4. 提示用户在 ToolHub 网站 `/#submit` 中先上传/导入 Markdown，再上传“引用资源”清单中的文件，最后点击提交校验。
5. 如用户还需要 Installer 离线导入包，可额外生成 v2 `.tapython-tool.zip`；该 ZIP 不作为 ToolHub 网站投稿方式。

### Step 6：提交前校验

在写入文件前，执行以下检查并在报告中列出结果：

| 检查项 | 通过条件 |
|--------|---------|
| `slug` 格式 | 全小写、仅含字母数字和连字符、不含下划线 |
| `version` 格式 | 符合 semver（`x.y.z`）|
| `schemaVersion` | front matter 固定为 `"1.0.0"` |
| `sourceMode` | 固定为 `markdown-with-external-files` |
| `@file:` 引用 | 每个引用都能在引用资源清单中找到 |
| 必填字段完整性 | `slug`、`name`、`displayName`、`version`、`author`、`ownerTeam`、`description`、`category`、`riskLevel`、`installPath`、`entryJson` 均已填写 |
| `summary.widgetAkas` | 与 UI JSON 中提取的 Aka 列表一致 |
| `summary.unrealApis` | 至少包含 Controller 中检测到的主要 API |
| 文件 sha256 | 资源清单中的 sha256 与实际文件内容匹配 |

**校验失败的字段**：在报告中标红提示，要求用户修正后重新生成。

---

## 常见字段取值参考

### category 参考值

| 值 | 适用场景 |
|----|---------|
| `level-editing` | 关卡编辑、Actor 管理、场景操作 |
| `asset-management` | 资产批量处理、命名、移动、Tag 管理 |
| `animation` | 动画序列、骨骼网格体、控制绑定相关 |
| `rendering` | 材质、光照、后处理、LOD |
| `pipeline` | 导入导出、版本控制、CI 流程集成 |
| `utility` | 通用工具、开发辅助、调试工具 |

### status 参考值

| 值 | 含义 |
|----|------|
| `approved` | 已通过内部审核，可直接投稿 |
| `pending` | 待审核，首次投稿通常使用此值 |
| `deprecated` | 已废弃，不建议安装 |

---

## 质量检查清单

生成文档后，逐项核对：

- [ ] ZIP 根目录包含 `manifest.json`
- [ ] `manifest.json.packageType` 为 `TAPythonToolPackage`，`formatVersion` 为 `2`
- [ ] `manifest.json.files[]` 中每个 `path` 都存在于 ZIP 内
- [ ] `manifest.json.files[]` 中每个 `sha256` 都是完整 64 位小写 hex，且与 ZIP 内实际内容一致
- [ ] `manifest.json.install.pythonRoot` 指向 `Python/<ToolName>`
- [ ] `manifest.json.install.targetPath` 指向 `<Project>/TA/TAPython/Python/<ToolName>`
- [ ] `manifest.json.menuEntries` 与 MenuConfig 提取结果一致
- [ ] `slug` 与 `name` 在团队内唯一
- [ ] `summary.widgetAkas` 与 UI JSON 一致
- [ ] `summary.unrealApis` 覆盖主要调用
- [ ] `preInstallChecks` / `postInstallSteps` / `uninstallSteps` 逻辑一致
- [ ] `Docs/tool.md` 或投稿说明无 placeholder 残留
- [ ] 所有中文描述字段已填写，无 placeholder 残留

---

## 已知陷阱与规避

| 陷阱 | 说明 | 规避方法 |
|------|------|---------|
| slug 含下划线 | Hub 会拒绝含 `_` 的 slug | 全部替换为 `-` |
| YAML 字符串含冒号 | `description: 工具: 批量改名` 会导致 YAML 解析失败 | 用引号包裹：`description: "工具: 批量改名"` |
| `@file:` 路径错误 | Hub 构建时找不到外部文件 | `@file:` 后的路径相对于 Markdown 文件，不含子目录前缀 |
| sha256 不一致 | 文件修改后忘记重新计算 | 在 Step 6 校验阶段自动对比 |
| sha256 使用短 hash | v2 schema 要求完整 64 位小写 hex | 始终使用 `Get-FileHash ... .Hash.ToLower()` 完整值 |
| `previousVersions` 条目缺少 `changeSummary` | Hub 校验报 `versions.N.changeSummary: Required`，即使顶层已有 `changeSummary` | 每个 `previousVersions` 条目都必须单独填写 `changeSummary` 字段 |
| version 未递增 | 同 slug 重复版本会被 Hub 拒绝 | 发布新版本时必须递增 semver |
| 仍把 Markdown 当安装源 | v2 以后 Markdown 只是展示文档 | 以 ZIP 内 `manifest.json` 为安装事实源 |
| menuEntries 与 MenuConfig 片段不一致 | 两处 JSON 内容不同步导致安装困惑 | 从项目 MenuConfig 提取后写入 `manifest.json.menuEntries`，Docs 只展示同一份数据 |

---

## 参考文档

- [TAPython Tool Hub 投稿规范](./references/hub-schema.md)（如存在）
- [Front Matter 字段完整说明](./references/front-matter-fields.md)（如存在）
- [existing tapython-doc-exporter skill](~/.copilot/skills/tapython-doc-exporter/SKILL.md) — 用于生成内部文档（与本 Skill 互补，不重复）
